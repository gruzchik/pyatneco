Cufon.replace('#header .nav a', { hover:true });
Cufon.replace('h3', { textShadow: '#e66f18 1px 1px' });
Cufon.replace('h1, h2');